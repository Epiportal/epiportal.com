#ifndef GREET_HH
# define GREET_HH

# include <string>

/// \brief Greet user \a name.
void greet(const std::string& name);

#endif // !GREET_HH
