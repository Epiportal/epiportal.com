#include "greet.hh"

#include <iostream>

void greet(const std::string& name)
{
  std::cout << "Hello, " << name << std::endl;
}
