#include "greet.hh"

int
main()
{
  greet("You");
}
