#include <iostream>
#include <fstream>

int
main(int argc, char* argv[])
{
  std::ifstream in(argv[1]);
  if (!in.good())
    exit(1);
  std::cout << in.rdbuf();
}
